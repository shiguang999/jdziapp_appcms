<?php


namespace App\Api\User;


use PhalApi\Api;
/**
 * 登录校验
 * @author dogstar 20170612
 */
class Check extends Api
{
    public function go(){

    }

}